package com.globaltranslate.keyboard

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Translator {
    fun translate(text: String, target: String, endpoint: String): String {
        require(endpoint.startsWith("https://")) { "آدرس سرویس ترجمه باید با https شروع شود." }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 9000
            readTimeout = 12000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val body = JSONObject()
                .put("q", text)
                .put("source", "auto")
                .put("target", target)
                .put("format", "text")
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("سرویس ترجمه پاسخ $code داد: $response")
            return JSONObject(response).optString("translatedText").ifBlank {
                throw IllegalStateException("پاسخ سرویس ترجمه قابل تشخیص نیست.")
            }
        } finally {
            connection.disconnect()
        }
    }
}
