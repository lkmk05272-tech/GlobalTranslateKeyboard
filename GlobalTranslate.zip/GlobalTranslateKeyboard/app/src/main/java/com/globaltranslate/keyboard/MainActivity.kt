package com.globaltranslate.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class MainActivity : Activity() {
    private val languages = linkedMapOf(
        "انگلیسی" to "en", "فارسی" to "fa", "عربی" to "ar",
        "فرانسوی" to "fr", "آلمانی" to "de", "اسپانیایی" to "es",
        "ترکی" to "tr", "روسی" to "ru", "چینی" to "zh",
        "ژاپنی" to "ja", "کره‌ای" to "ko", "هندی" to "hi",
        "ایتالیایی" to "it", "پرتغالی" to "pt"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Global Translate Keyboard"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "زبان مقصد را انتخاب کن. سپس کیبورد را فعال کن."
            textSize = 16f
            setPadding(0, 18, 0, 18)
        })
        val spinner = Spinner(this)
        val names = languages.keys.toList()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val saved = Prefs.target(this)
        spinner.setSelection(languages.values.indexOf(saved).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                Prefs.setTarget(this@MainActivity, languages[names[position]] ?: "en")
            }
        }
        layout.addView(spinner)

        layout.addView(TextView(this).apply {
            text = "آدرس سرویس ترجمه (سازگار با LibreTranslate)"
            setPadding(0, 24, 0, 6)
        })
        val endpoint = EditText(this).apply {
            setSingleLine(true)
            textSize = 13f
            setText(Prefs.endpoint(this@MainActivity))
            hint = "https://your-translation-server/translate"
        }
        layout.addView(endpoint)
        layout.addView(Button(this).apply {
            text = "ذخیره تنظیمات"
            setOnClickListener {
                Prefs.setEndpoint(this@MainActivity, endpoint.text.toString())
                Toast.makeText(this@MainActivity, "تنظیمات ذخیره شد", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "فعال‌کردن کیبورد"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "انتخاب کیبورد"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        layout.addView(TextView(this).apply {
            text = "نکته: برای ترجمه واقعی، یک سرویس سازگار با LibreTranslate و اینترنت لازم است. سرویس پیش‌فرض ممکن است در دسترس نباشد یا محدودیت داشته باشد."
            textSize = 13f
            setPadding(0, 20, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
