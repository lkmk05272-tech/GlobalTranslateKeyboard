package com.globaltranslate.keyboard

import android.content.Context

object Prefs {
    private const val FILE = "global_translate_prefs"
    private const val TARGET = "target_language"
    private const val ENDPOINT = "endpoint"
    fun target(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(TARGET, "en") ?: "en"
    fun setTarget(context: Context, value: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(TARGET, value).apply()
    }
    fun endpoint(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(ENDPOINT, "https://translate.argosopentech.com/translate") ?: ""
    fun setEndpoint(context: Context, value: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(ENDPOINT, value.trim()).apply()
    }
}
