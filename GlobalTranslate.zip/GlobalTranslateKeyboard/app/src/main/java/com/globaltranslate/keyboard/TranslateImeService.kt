package com.globaltranslate.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.Executors

class TranslateImeService : InputMethodService() {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val draft = StringBuilder()
    private var preview = ""
    private var isPersian = false
    private lateinit var previewView: TextView
    private lateinit var statusView: TextView
    private val debounce = Runnable { requestTranslation() }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 5, 5, 5)
            setBackgroundColor(Color.rgb(235, 238, 244))
        }
        val toolbar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        statusView = TextView(this).apply {
            text = "ترجمه زنده"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(8, 8, 8, 8)
        }
        toolbar.addView(statusView, LinearLayout.LayoutParams(0, 42, 1f))
        toolbar.addView(keyButton("⚙") {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            if (intent != null) startActivity(intent)
        })
        root.addView(toolbar)
        previewView = TextView(this).apply {
            text = "متن را تایپ کن؛ ترجمه اینجا نمایش داده می‌شود."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(10, 8, 10, 8)
            setBackgroundColor(Color.WHITE)
            minHeight = 42
        }
        root.addView(previewView)
        val rows = if (isPersian) listOf(
            "ض ص ث ق ف غ ع ه خ ح ج چ",
            "ش س ی ب ل ا ت ن م ک گ",
            "ظ ط ز ر ذ د ئ و پ"
        ) else listOf(
            "q w e r t y u i o p",
            "a s d f g h j k l",
            "z x c v b n m"
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER; weightSum = row.split(" ").size.toFloat() }
            row.split(" ").forEach { key ->
                line.addView(keyButton(key) { addCharacter(key) }, LinearLayout.LayoutParams(0, 46, 1f).apply {
                    setMargins(2, 3, 2, 3)
                })
            }
            root.addView(line)
        }
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(keyButton(if (isPersian) "EN" else "فا") {
            isPersian = !isPersian
            draft.clear(); preview = ""; main.removeCallbacks(debounce)
            setInputView(onCreateInputView())
        }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(keyButton("⌫") { if (draft.isNotEmpty()) draft.deleteCharAt(draft.length - 1); refreshAndTranslate() },
            LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(keyButton("فاصله") { commitTranslated(" ") }, LinearLayout.LayoutParams(0, 48, 2f))
        bottom.addView(keyButton("↵") { commitTranslated("\n") }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(bottom)
        return root
    }

    private fun keyButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.BLACK)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, 0)
            setOnClickListener { action() }
        }

    private fun addCharacter(value: String) {
        draft.append(value)
        refreshAndTranslate()
    }

    private fun refreshAndTranslate() {
        preview = ""
        previewView.text = draft.toString()
        statusView.text = "در حال آماده‌سازی ترجمه…"
        main.removeCallbacks(debounce)
        if (draft.isNotEmpty()) main.postDelayed(debounce, 650)
    }

    private fun requestTranslation() {
        val source = draft.toString()
        if (source.isBlank()) return
        val target = Prefs.target(this)
        val endpoint = Prefs.endpoint(this)
        worker.execute {
            try {
                val result = Translator.translate(source, target, endpoint)
                main.post {
                    if (draft.toString() == source) {
                        preview = result
                        previewView.text = result
                        statusView.text = "ترجمه آماده است"
                    }
                }
            } catch (e: Exception) {
                main.post {
                    statusView.text = "ترجمه در دسترس نیست"
                    previewView.text = source
                }
            }
        }
    }

    private fun commitTranslated(separator: String) {
        main.removeCallbacks(debounce)
        val text = preview.ifBlank { draft.toString() }
        if (text.isNotBlank()) currentInputConnection?.commitText(text + separator, 1)
        draft.clear()
        preview = ""
        previewView.text = "متن بعدی…"
        statusView.text = "ترجمه زنده"
    }

    override fun onFinishInput() {
        main.removeCallbacks(debounce)
        draft.clear()
        preview = ""
        super.onFinishInput()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
